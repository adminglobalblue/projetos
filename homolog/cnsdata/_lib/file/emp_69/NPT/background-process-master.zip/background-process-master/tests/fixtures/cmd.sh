#!/bin/bash

echo "ok" > tests/fixtures/runShouldRunCommand.log
